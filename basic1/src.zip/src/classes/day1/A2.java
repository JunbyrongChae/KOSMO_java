package classes.day1;

public class A2 {
    //A1 a1 = new A1();
    public A2(){
        System.out.println("A2디폴트생성자 입니다.");
    }
    public static void main(String[] args) {
    A2 a2 = new A2();
    }
}
