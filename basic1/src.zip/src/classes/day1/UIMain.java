package classes.day1;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UIMain extends JFrame implements ActionListener {

    public void initDisplsy(){
        this.setSize(350,600);
    }

    public static void main(String[] args) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
