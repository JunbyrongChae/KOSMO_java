package day2;
import javax.swing.*;

public class JFrame2 {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame();
        String title = "KakaoTalk";
        jFrame.setTitle(title);
        int width = 500;
        int height = 300;
        jFrame.setSize(width, height);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }//// end of main
}//////// end of JFrame2
