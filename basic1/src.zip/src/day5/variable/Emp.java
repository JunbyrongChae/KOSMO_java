package day5.variable;
//main메소드가 없는 클래스 선언해 봅니다.
//테이블 구조로 보았을 때 로우값을 담을 수 있는 클래스 선언이다.
//Emp클래스는 읽고 쓰기위한 메쏘드를 정의하는 클래스입니다.
public class Emp {
    //멤버변수(전역변수)
    public int empno=0;
    public String ename=null;
    public double salary=0.0;
}
