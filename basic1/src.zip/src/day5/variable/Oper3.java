package day5.variable;

public class Oper3 {
    public static void main(String[] args) {
        int end=5;
        for(int i =1;i<=end;i++){//1~3까지 증가
            if(i%2==0){ //%연산자는 어떤정수를 2로 나눈 나머지를 구함
                System.out.println(i);//2 4 배열
            }
            System.out.println(i);//1,2,3,4,5 배열
            //for(선언+초기화;조건식;증감연산자)
        }////// end of for
    }////////// end of main
}////////////// end of class
