package day5.variable;

public class Oper2 {
    public static void main(String[] args) {
        /******************************
        *int i =1;
         int j = i++; //j=i, i=i+1
        //변수++는 i를 변수에 대입후 증가
        //System.out.println(i); //2
        //System.out.println(j); //1

         *int j=++i;
        //j=i, i=i+1, j=2
        //++변수는 먼저 1을 증가 후 대입
        //System.out.println(i); //2
        //System.out.println(j); //2
         ******************************/

        /******************************
        int i =3;
        int j = --i;
        System.out.println(i);//2
        System.out.println(j);//2

        int j = i--;
        System.out.println(i);//2
        System.out.println(j);//3
        *******************************/

    }
}
