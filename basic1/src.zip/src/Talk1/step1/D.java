package Talk1.step1;

public interface D {
    //호출할 때 처럼 맨 뒤에 세미콜론이 있다. 그런데 호출이 아니라
    //명세서의 역할을 하는 메소드 원형만 약속함 - implements구현체 클래스를 만들어라
    //{}가 없는 메소드를 바디가 없다
    public abstract void methodA();//추상 메소드라고 함.
}
