package Quiz.step1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

//collection
public class Q24 {
    /*
    public static Integer reverse(List list){
        Collection.reverse(list);
        return list.iterator();
    }

    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("1");
        list.add("2");
        list.add("3");
        for(Object obj: reverse(list)) {
            System.out.println(obj + ",");
        }
    }*/
}


/*********************************************
 ‘What is the result?
 A. 3, 2, 1,
 B. 1, 2, 3,
 C. Compilation fails.
 D. The code runs with no output.
 E. An exception is thrown at runtime.
***********************************************/