package Quiz.step1;
//if문
public class Q17 {
   /*
    public void testIFA() {
        if (testIFB("true")) {
            System.out.println("True");
        } else {
            System.out.println("Not true");
        }
        public Boolean testIFB (String str){
            return Boolean.valueOf(str);
        }

    }*/

    public static void main(String[] args) {
    }
}

/********************************************
 What is the result when method testIfA is invoked?  //메서드 testIfA가 호출될 때 결과는 무엇인가?
 A. True
 B. Not true
 C. An exception is thrown at runtime.
 D. Compilation fails because of an error at line 12.
 E. Compilation fails because of an error at line 19.
******************************************************************************/