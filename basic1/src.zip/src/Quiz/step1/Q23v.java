package Quiz.step1;
//do while문
public class Q23v {
    public static void main(String[] args) {
        int x =10;
        do {
            x--;
        } while(x < 10);
    }
}

/********************************************
 How many times will line 37 be executed?
 A. ten times
 B. zero times
 C. one to me times
 D. more than ten times (v)
 ****************************************/