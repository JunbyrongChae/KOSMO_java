package Quiz.step1;
//private 멤버필드 접근방법(set,get의 형식)
public class Q9 {
    private boolean enabled;
}


/***********************************************************************
 * A JavaBeans component has the following field:
  11. private boolean enabled;  //boolean형 멤버필드
 Which two pairs of method declarations follow the JavaBeans standard for accessing this field? (Choose two.)
 //이 멤버필드에 접근하기 위해서 자바표준에 따라 정의된 메서드쌍을 두개는 어떤것인가?
 A. public void setEnabled( boolean enabled)
    public boolean getEnabled()
 B. public void setEnabled( boolean enabled)
    public void isEnabled()
 C. public void setEnabled( boolean enabled)
    public boolean isEnabled()
 D. public boolean setEnabled( boolean enabled)
    public boolean getEnabled()
 ***********************************************************************/