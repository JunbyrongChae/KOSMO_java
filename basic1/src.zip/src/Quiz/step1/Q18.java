package Quiz.step1;
//오토박싱과 swich문
public class Q18 {
   /*
    public static void main(String[] args) {
        Integer i = new Integer(1)+new Integer(2);
        switch (i){
            case 3:
                System.out.println("three");
                break;
            default:
                System.out.println("other");
                break;
        }
    }*/
}

/******************************************************
‘What is the result?
A. three
B. other
C. An exception is thrown at runtime.
D. Compilation fails because of an error on line 12.(v)
E. Compilation fails because of an error on line 13.
F. Compilation fails because of an error on line 15.
 ********************************************************/
