package Quiz.step1;
//오버로딩
public class Q11v {
    public void doit(){
    }/*
    public String doit(){//위의 public void doit()의 인자의 개수와 데이터형이 같으면 오류
        return "a"; }
    public double doit(int x){
        return 1.0;}*/
}


/*********************************************
 * What is the result?
 * A. An exception is thrown at runtime.
 * B. Compilation fails because of an error in line 8.
 * C. Compilation fails because of an error in line 6.(v)
 * D. Compilation succeeds and no runtime errors with class A occur.
 ********************************************************************/