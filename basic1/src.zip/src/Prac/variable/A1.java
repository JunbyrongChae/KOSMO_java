package Prac.variable;

class A1 {
    int i;//int 디폴트값 0
    //전역변수 - 외부 다른 클래스에서 호출 가능!!!!!(재사용성)
    //<-> 지역변수 - 외부 다른 클래스에서 호출 불가!!!!
}

