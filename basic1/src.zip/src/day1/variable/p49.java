package day1.variable;

import java.sql.SQLOutput;

public class p49 {
    static int hap(int i, int j){
        return i+j;
    }
    public static void main(String[] args) {
        System.out.println(hap(1,2));
        int a = 3;
        String b = "출력";
        b = "문자형";
        System.out.println("화면출력");
        System.out.println("화면출력");
        System.out.println(a+b);
        System.out.println(a+b);
        System.out.println(a+b);

        System.out.println("hello");
        System.out.print(10);
    }
}
