package day6.variable;

public class M extends Object{
    public static void main(String[] args) {
        M m = new M();
        System.out.println(m.toString());
    }
}
