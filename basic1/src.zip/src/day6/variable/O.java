package day6.variable;

import javax.swing.*;

public class O {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        System.out.printf("%s   ",frame);
        JButton button = new JButton();
        System.out.printf("\n%s   ",button);
    }
}
